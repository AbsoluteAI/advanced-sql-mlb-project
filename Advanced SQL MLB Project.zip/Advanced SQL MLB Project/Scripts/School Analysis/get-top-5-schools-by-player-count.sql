-- What are the names of the top 5 schools that produced the most players?
SELECT sd.name_full, COUNT(DISTINCT ss.playerid) AS player_count
FROM schools ss
JOIN school_details sd ON ss.schoolid = sd.schoolid
GROUP BY sd.name_full
ORDER BY player_count DESC LIMIT 5;