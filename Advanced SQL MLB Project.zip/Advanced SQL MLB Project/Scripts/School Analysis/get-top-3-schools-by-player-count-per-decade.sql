-- For each decade, what were the names of the top 3 schools that produced the most players?
WITH dec AS (SELECT FLOOR(yearid / 10) * 10 AS decade, sd.name_full, COUNT(DISTINCT ss.playerid) AS player_count
			 FROM schools ss
			 JOIN school_details sd ON ss.schoolid = sd.schoolid
			 GROUP BY decade, sd.name_full
			 ORDER BY decade),
player_row AS	(SELECT decade, name_full, player_count, ROW_NUMBER() OVER(PARTITION BY decade ORDER BY player_count DESC) AS row_num
				 FROM dec)

SELECT decade, name_full
FROM player_row
WHERE row_num IN (1, 2, 3);