-- In each decade, how many schools produced MLB players?
SELECT FLOOR(yearid / 10) * 10 AS decade, COUNT(DISTINCT schoolid) AS school_count
FROM schools
GROUP BY decade
ORDER BY decade;