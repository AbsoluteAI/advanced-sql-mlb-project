-- How have average height and weight at debut games changed over the years,
-- and what's the decade-over-decade difference?
WITH debut_stats AS (SELECT EXTRACT(DECADE FROM debut) * 10 AS debut_decade,
									height,
									weight
					FROM players),
					
	 debut_avg   AS (SELECT debut_decade, ROUND(AVG(height), 2) AS avg_height, ROUND(AVG(weight), 2) AS avg_weight	   
					FROM debut_stats
					GROUP BY debut_decade)
					
SELECT debut_decade,
	   COALESCE(avg_height - LAG(avg_height) OVER(ORDER BY debut_decade), 0) AS height_difference,
	   COALESCE(avg_weight - LAG(avg_weight) OVER(ORDER BY debut_decade), 0) AS weight_difference
FROM debut_avg;