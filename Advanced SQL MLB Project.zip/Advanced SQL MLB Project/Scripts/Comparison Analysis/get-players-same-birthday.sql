-- Which players have the same birthday?
WITH player_birthdate AS (SELECT playerid, namegiven, CONCAT(birthyear::TEXT, '-', birthmonth::TEXT, '-', birthday::TEXT)::DATE AS birth_date
						  FROM players
						  WHERE birthday IS NOT NULL AND birthday > 0)
						  
SELECT birth_date, string_agg(namegiven, ', ') AS player_list
FROM player_birthdate
WHERE EXTRACT(YEAR FROM birth_date) BETWEEN 1980 AND 1990
GROUP BY birth_date
ORDER BY birth_date;