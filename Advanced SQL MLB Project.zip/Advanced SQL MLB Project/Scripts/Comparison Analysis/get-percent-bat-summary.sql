-- Create a summary table that shows for each team, what percent of players bat right, left, and both
SELECT s.teamid,
	   ROUND(SUM(CASE WHEN p.bats = 'R' THEN 1 ELSE 0 END)::NUMERIC / COUNT(s.playerid) * 100, 1) AS right_bat,
	   ROUND(SUM(CASE WHEN p.bats = 'L' THEN 1 ELSE 0 END)::NUMERIC / COUNT(s.playerid) * 100, 1) AS left_bat,
	   ROUND(SUM(CASE WHEN p.bats = 'B' THEN 1 ELSE 0 END)::NUMERIC / COUNT(s.playerid) * 100, 1) AS amb_bat
FROM salaries s
JOIN players p ON s.playerid = p.playerid
GROUP BY s.teamid
ORDER BY teamid;