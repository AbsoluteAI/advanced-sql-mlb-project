-- What team did each player play on for their starting and ending years?
SELECT s.playerid, p.namegiven, s.yearid AS debut_year, s.teamid, s2.yearid, s2.teamid
FROM players p
INNER JOIN salaries s ON p.playerid = s.playerid
AND EXTRACT(YEAR FROM debut) = s.yearid
	INNER JOIN salaries s2 ON p.playerid = s2.playerid
			   AND EXTRACT(YEAR FROM p.finalgame) = s2.yearid
ORDER BY s.playerid;