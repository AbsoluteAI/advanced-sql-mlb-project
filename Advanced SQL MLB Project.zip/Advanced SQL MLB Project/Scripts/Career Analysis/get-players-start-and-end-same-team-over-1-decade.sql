-- How many players started and ended on the same team and also played for over a decade?
SELECT s.playerid, p.namegiven, s.yearid AS debut_year, s.teamid, s2.yearid AS final_year, s2.teamid
FROM players p
INNER JOIN salaries s ON p.playerid = s.playerid
AND EXTRACT(YEAR FROM debut) = s.yearid
	INNER JOIN salaries s2 ON p.playerid = s2.playerid
			   AND EXTRACT(YEAR FROM p.finalgame) = s2.yearid
WHERE s.teamid = s2.teamid AND s2.yearid - s.yearid > 10
ORDER BY s.playerid;