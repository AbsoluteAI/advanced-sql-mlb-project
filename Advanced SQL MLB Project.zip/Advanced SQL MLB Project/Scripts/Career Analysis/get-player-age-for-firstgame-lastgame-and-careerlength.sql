-- For each player, calculate their age at their first debut game, their last game, and their career length(in years)
-- Sort from longest career to shortest career
WITH dob AS (SELECT playerid, namegiven, CONCAT(birthyear::TEXT, '-', birthmonth::TEXT, '-', birthday::TEXT)::DATE AS birth_date,
					debut, finalgame
			FROM players
			WHERE birthday IS NOT NULL AND birthday > 0),
			
null_op  AS (SELECT playerid, namegiven, birth_date, COALESCE(debut, LAG(debut) OVER(), LEAD(debut) OVER()) AS debut,
										 COALESCE(finalgame, LAG(finalgame) OVER (), LEAD(finalgame) OVER()) AS finalgame
			FROM dob)
SELECT playerid, namegiven,
	   EXTRACT(YEAR FROM AGE(debut, birth_date)) AS debut_age,
	   EXTRACT(YEAR FROM AGE(finalgame, birth_date)) AS final_age,
	   COALESCE(EXTRACT(YEAR FROM AGE(finalgame, debut))) AS career_length
FROM null_op
ORDER BY career_length DESC;