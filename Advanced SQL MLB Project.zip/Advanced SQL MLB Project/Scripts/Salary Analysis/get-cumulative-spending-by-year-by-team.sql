-- For each team, show the cumulative sum of spending over the years
SELECT * FROM salaries;
WITH rolling_subtotals AS (SELECT teamid, yearid, SUM(salary) AS sum_salary
							FROM salaries
							GROUP BY teamid, yearid
							ORDER BY teamid, yearid)
SELECT teamid, yearid,
	   SUM(sum_salary) OVER(PARTITION BY teamid ORDER BY yearid) AS cumulative_salary
FROM rolling_subtotals
GROUP BY teamid, yearid, sum_salary;