-- Return the first year that each team's cumulative spending surpassed 1 billion dollars
WITH sum_salary AS (SELECT teamid, yearid,
						   SUM(salary) AS sum_salary
					FROM salaries
					GROUP BY teamid, yearid
					ORDER BY teamid, yearid),
					
rolling_salary  AS (SELECT teamid, yearid, sum_salary,
						   SUM(sum_salary) OVER(PARTITION BY teamid ORDER BY yearid) AS cumulative_salary
					FROM sum_salary),
					
salary_rank		AS	(SELECT teamid, yearid, cumulative_salary,
							RANK() OVER(PARTITION BY teamid ORDER BY yearid) AS year_rank
					FROM rolling_salary
					WHERE cumulative_salary > 1000000000)
					
SELECT teamid, yearid, cumulative_salary
FROM salary_rank
WHERE year_rank = 1;