-- Return the top 20 percent of teams in terms of average annual spending
SELECT * FROM salaries;
WITH spend_total AS (SELECT teamid, yearid, ROUND(SUM(salary)) AS sum_salary
					FROM salaries
					GROUP BY teamid, yearid
					ORDER BY teamid, yearid),
	 spend_rank  AS (SELECT teamid, ROUND(AVG(sum_salary)) AS avg_salary,
	 						RANK() OVER(ORDER BY AVG(sum_salary) DESC) AS avg_rank,
						    NTILE(5) OVER() AS top_perc
					FROM spend_total
					GROUP BY teamid)
SELECT teamid, avg_salary
FROM spend_rank
WHERE top_perc = 1
ORDER BY avg_rank;