/****************************
Assignment 1: School Analysis
****************************/
-- In each decade, how many schools produced MLB players?
SELECT FLOOR(yearid / 10) * 10 AS decade, COUNT(DISTINCT schoolid) AS school_count
FROM schools
GROUP BY decade
ORDER BY decade;

-- What are the names of the top 5 schools that produced the most players?
SELECT sd.name_full, COUNT(DISTINCT ss.playerid) AS player_count
FROM schools ss
JOIN school_details sd ON ss.schoolid = sd.schoolid
GROUP BY sd.name_full
ORDER BY player_count DESC LIMIT 5;

-- For each decade, what were the names of the top 3 schools that produced the most players?
WITH dec AS (SELECT FLOOR(yearid / 10) * 10 AS decade, sd.name_full, COUNT(DISTINCT ss.playerid) AS player_count
			 FROM schools ss
			 JOIN school_details sd ON ss.schoolid = sd.schoolid
			 GROUP BY decade, sd.name_full
			 ORDER BY decade),
player_row AS	(SELECT decade, name_full, player_count, ROW_NUMBER() OVER(PARTITION BY decade ORDER BY player_count DESC) AS row_num
				 FROM dec)

SELECT decade, name_full
FROM player_row
WHERE row_num IN (1, 2, 3);

/****************************
Assignment 2: Salary Analysis
****************************/
-- Return the top 20 percent of teams in terms of average annual spending
SELECT * FROM salaries;
WITH spend_total AS (SELECT teamid, yearid, ROUND(SUM(salary)) AS sum_salary
					FROM salaries
					GROUP BY teamid, yearid
					ORDER BY teamid, yearid),
	 spend_rank  AS (SELECT teamid, ROUND(AVG(sum_salary)) AS avg_salary,
	 						RANK() OVER(ORDER BY AVG(sum_salary) DESC) AS avg_rank,
						    NTILE(5) OVER() AS top_perc
					FROM spend_total
					GROUP BY teamid)
SELECT teamid, avg_salary
FROM spend_rank
WHERE top_perc = 1
ORDER BY avg_rank;

-- For each team, show the cumulative sum of spending over the years
SELECT * FROM salaries;
WITH rolling_subtotals AS (SELECT teamid, yearid, SUM(salary) AS sum_salary
							FROM salaries
							GROUP BY teamid, yearid
							ORDER BY teamid, yearid)
SELECT teamid, yearid,
	   SUM(sum_salary) OVER(PARTITION BY teamid ORDER BY yearid) AS cumulative_salary
FROM rolling_subtotals
GROUP BY teamid, yearid, sum_salary;

-- Return the first year that each team's cumulative spending surpassed 1 billion dollars
WITH sum_salary AS (SELECT teamid, yearid,
						   SUM(salary) AS sum_salary
					FROM salaries
					GROUP BY teamid, yearid
					ORDER BY teamid, yearid),
					
rolling_salary  AS (SELECT teamid, yearid, sum_salary,
						   SUM(sum_salary) OVER(PARTITION BY teamid ORDER BY yearid) AS cumulative_salary
					FROM sum_salary),
					
salary_rank		AS	(SELECT teamid, yearid, cumulative_salary,
							RANK() OVER(PARTITION BY teamid ORDER BY yearid) AS year_rank
					FROM rolling_salary
					WHERE cumulative_salary > 1000000000)
					
SELECT teamid, yearid, cumulative_salary
FROM salary_rank
WHERE year_rank = 1;

/***********************************
Assignment 3: Player Career Analysis
***********************************/
-- For each player, calculate their age at their first debut game, their last game, and their career length(in years)
-- Sort from longest career to shortest career
WITH dob AS (SELECT playerid, namegiven, CONCAT(birthyear::TEXT, '-', birthmonth::TEXT, '-', birthday::TEXT)::DATE AS birth_date,
					debut, finalgame
			FROM players
			WHERE birthday IS NOT NULL AND birthday > 0),
			
null_op  AS (SELECT playerid, namegiven, birth_date, COALESCE(debut, LAG(debut) OVER(), LEAD(debut) OVER()) AS debut,
										 COALESCE(finalgame, LAG(finalgame) OVER (), LEAD(finalgame) OVER()) AS finalgame
			FROM dob)
SELECT playerid, namegiven,
	   EXTRACT(YEAR FROM AGE(debut, birth_date)) AS debut_age,
	   EXTRACT(YEAR FROM AGE(finalgame, birth_date)) AS final_age,
	   COALESCE(EXTRACT(YEAR FROM AGE(finalgame, debut))) AS career_length
FROM null_op
ORDER BY career_length DESC;

-- What team did each player play on for their starting and ending years?
SELECT s.playerid, p.namegiven, s.yearid AS debut_year, s.teamid, s2.yearid, s2.teamid
FROM players p
INNER JOIN salaries s ON p.playerid = s.playerid
AND EXTRACT(YEAR FROM debut) = s.yearid
	INNER JOIN salaries s2 ON p.playerid = s2.playerid
			   AND EXTRACT(YEAR FROM p.finalgame) = s2.yearid
ORDER BY s.playerid;

-- How many players started and ended on the same team and also played for over a decade?
SELECT s.playerid, p.namegiven, s.yearid AS debut_year, s.teamid, s2.yearid AS final_year, s2.teamid
FROM players p
INNER JOIN salaries s ON p.playerid = s.playerid
AND EXTRACT(YEAR FROM debut) = s.yearid
	INNER JOIN salaries s2 ON p.playerid = s2.playerid
			   AND EXTRACT(YEAR FROM p.finalgame) = s2.yearid
WHERE s.teamid = s2.teamid AND s2.yearid - s.yearid > 10
ORDER BY s.playerid;

/***************************************
Assignment 4: Player Comparison Analysis
***************************************/
-- Which players have the same birthday?
WITH player_birthdate AS (SELECT playerid, namegiven, CONCAT(birthyear::TEXT, '-', birthmonth::TEXT, '-', birthday::TEXT)::DATE AS birth_date
						  FROM players
						  WHERE birthday IS NOT NULL AND birthday > 0)
						  
SELECT birth_date, string_agg(namegiven, ', ') AS player_list
FROM player_birthdate
WHERE EXTRACT(YEAR FROM birth_date) BETWEEN 1980 AND 1990
GROUP BY birth_date
ORDER BY birth_date;

-- Create a summary table that shows for each team, what percent of players bat right, left, and both
SELECT s.teamid,
	   ROUND(SUM(CASE WHEN p.bats = 'R' THEN 1 ELSE 0 END)::NUMERIC / COUNT(s.playerid) * 100, 1) AS right_bat,
	   ROUND(SUM(CASE WHEN p.bats = 'L' THEN 1 ELSE 0 END)::NUMERIC / COUNT(s.playerid) * 100, 1) AS left_bat,
	   ROUND(SUM(CASE WHEN p.bats = 'B' THEN 1 ELSE 0 END)::NUMERIC / COUNT(s.playerid) * 100, 1) AS amb_bat
FROM salaries s
JOIN players p ON s.playerid = p.playerid
GROUP BY s.teamid
ORDER BY teamid;

-- How have average height and weight at debut games changed over the years,
-- and what's the decade-over-decade difference?
WITH debut_stats AS (SELECT EXTRACT(DECADE FROM debut) * 10 AS debut_decade,
									height,
									weight
					FROM players),
					
	 debut_avg   AS (SELECT debut_decade, ROUND(AVG(height), 2) AS avg_height, ROUND(AVG(weight), 2) AS avg_weight	   
					FROM debut_stats
					GROUP BY debut_decade)
					
SELECT debut_decade,
	   COALESCE(avg_height - LAG(avg_height) OVER(ORDER BY debut_decade), 0) AS height_difference,
	   COALESCE(avg_weight - LAG(avg_weight) OVER(ORDER BY debut_decade), 0) AS weight_difference
FROM debut_avg;